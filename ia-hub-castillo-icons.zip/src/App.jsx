export default function App() {
  return (
    <div className="h-screen flex items-center justify-center bg-gray-900 text-white">
      <div className="text-center">
        <h1 className="text-3xl font-bold">🚀 IA Hub_Castillo</h1>
        <p className="mt-2 text-lg">Accede a tus plataformas de Inteligencia Artificial</p>

        <div className="mt-6 space-y-3">
          <a href="https://chat.openai.com" target="_blank" className="block bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg">ChatGPT</a>
          <a href="https://gemini.google.com" target="_blank" className="block bg-green-600 hover:bg-green-700 px-4 py-2 rounded-lg">Gemini</a>
          <a href="https://claude.ai" target="_blank" className="block bg-purple-600 hover:bg-purple-700 px-4 py-2 rounded-lg">Claude</a>
        </div>
      </div>
    </div>
  );
}

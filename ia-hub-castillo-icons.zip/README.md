# 🚀 IA Hub_Castillo

Aplicación **PWA** para centralizar accesos a plataformas de Inteligencia Artificial.

## 📌 Tecnologías
- React + Vite
- TailwindCSS (opcional)
- Vite PWA Plugin

## 🚀 Cómo ejecutar en local
```bash
npm install
npm run dev
```

## 🌐 Cómo desplegar en Netlify
1. Subir este repo a GitHub.
2. Conectar GitHub con Netlify.
3. Configurar:
   - Build Command: `npm run build`
   - Publish Directory: `dist`
4. Deploy y listo ✅.

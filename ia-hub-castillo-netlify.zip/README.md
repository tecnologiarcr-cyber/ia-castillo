# IA Hub Castillo

Aplicación PWA para alojar accesos a plataformas de IA.

---

## 🚀 Desplegar en Netlify

Haz clic en el siguiente botón para desplegar directamente:

[![Deploy to Netlify](https://www.netlify.com/img/deploy/button.svg)](https://app.netlify.com/start/deploy?repository=https://github.com/tu-usuario/ia-hub-castillo)
